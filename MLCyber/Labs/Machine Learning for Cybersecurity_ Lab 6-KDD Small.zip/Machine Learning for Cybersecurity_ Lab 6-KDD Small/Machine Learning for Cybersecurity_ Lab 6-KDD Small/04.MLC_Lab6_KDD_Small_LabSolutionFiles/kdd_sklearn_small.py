import numpy as np
import pandas as pd
from numpy import genfromtxt
from sklearn import svm
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler

###############################################################


x_train=genfromtxt('train_kdd_small.csv',delimiter=',',usecols=(i for i in range(0,41)),\
    dtype=str,encoding="utf-8",skip_header=1)
y_train=genfromtxt('train_kdd_small.csv',delimiter=',',usecols=(-1),\
    dtype=str,encoding="utf-8",skip_header=1)
x_test=genfromtxt('test_kdd_small.csv',delimiter=',',usecols=(i for i in range(0,41)),\
    dtype=str,encoding="utf-8",skip_header=1)
y_test=genfromtxt('test_kdd_small.csv',delimiter=',',usecols=(-1),\
    dtype=str,encoding="utf-8",skip_header=1)
for c in range(1,4):
    x_train[:,c]=LabelEncoder().fit_transform(x_train[:,c])
    x_test[:,c]=LabelEncoder().fit_transform(x_test[:,c])
x_train=x_train.astype(np.float)
x_test=x_test.astype(np.float)
x_train = StandardScaler().fit_transform(x_train)
x_test = StandardScaler().fit_transform(x_test)
y_train = LabelEncoder().fit_transform(y_train)
y_test = LabelEncoder().fit_transform(y_test)
print("Begin:__________________________________")
###################################################
## print stats 

def print_stats_metrics(y_test, y_pred):    
    print('Accuracy: %.2f' % accuracy_score(y_test,y_pred) )
    confmat = confusion_matrix(y_true=y_test, y_pred=y_pred)
    print ("confusion matrix")
    print(confmat)
    print (pd.crosstab(y_test, y_pred, rownames=['True'], colnames=['Predicted'], margins=True))
    print('Precision: %.3f' % precision_score(y_true=y_test, y_pred=y_pred))
    print('Recall: %.3f' % recall_score(y_true=y_test, y_pred=y_pred))
    print('F1-measure: %.3f' % f1_score(y_true=y_test, y_pred=y_pred))


#######################Support Vector Machine#######################
print("#######################Support Vector Machine#######################")
clfSvm = svm.SVC(gamma='scale')
clfSvm.fit(x_train,y_train)
predictions = clfSvm.predict(x_test)
print_stats_metrics(y_test, predictions)

#######################Logistic Regression##########################
print("#######################Logistic Regression##########################")
clfLog = LogisticRegression(solver='lbfgs', multi_class='auto')
clfLog.fit(x_train,y_train)
predictions = clfLog.predict(x_test)
print_stats_metrics(y_test, predictions)

#######################Random Forest#######################
#print("#######################Random Forest#######################")
clfRF = RandomForestClassifier()
clfRF.fit(x_train,y_train)
predictions = clfSvm.predict(x_test)
print("#######################Random Forest#######################")
print_stats_metrics(y_test, predictions)
