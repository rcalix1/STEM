import pandas as pd
from numpy import genfromtxt
from sklearn import svm
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler

###############################################################


feature=genfromtxt('iris.csv',delimiter=',',usecols=(i for i in range(0,4)),dtype=float,skip_header=1)
class_value=genfromtxt('iris.csv',delimiter=',',usecols=(-1),dtype=str,skip_header=1)
labels = LabelEncoder().fit_transform(class_value)
feature_std = StandardScaler().fit_transform(feature)
x_train, x_test, y_train, y_test = train_test_split(feature_std, labels, test_size=0.30, random_state=0)

print("Begin:__________________________________")
###################################################
## print stats 
precision_scores_list = []
accuracy_scores_list = []

def print_stats_metrics(y_test, y_pred):    
    
    print('Accuracy: %.2f' % accuracy_score(y_test,   y_pred) )
    #Accuracy: 0.84
    accuracy_scores_list.append(accuracy_score(y_test,   y_pred) )
    confmat = confusion_matrix(y_true=y_test, y_pred=y_pred)
    print ("confusion matrix")
    print(confmat)
    print (pd.crosstab(y_test, y_pred, rownames=['True'], colnames=['Predicted'], margins=True))
    precision_scores_list.append(precision_score(y_true=y_test, y_pred=y_pred,average='weighted'))
    print('Precision: %.3f' % precision_score(y_true=y_test, y_pred=y_pred,average="weighted"))
    print('Recall: %.3f' % recall_score(y_true=y_test, y_pred=y_pred,average='weighted'))
    print('F1-measure: %.3f' % f1_score(y_true=y_test, y_pred=y_pred,average='weighted'))


#######################Support Vector Machine#######################
print("#######################Support Vector Machine#######################")
clfSvm = svm.SVC(gamma='scale')
clfSvm.fit(x_train,y_train)
predictions = clfSvm.predict(x_test)
print_stats_metrics(y_test, predictions)

#######################Logistic Regression##########################
print("#######################Logistic Regression##########################")
clfLog = LogisticRegression(solver='lbfgs', multi_class='auto')
clfLog.fit(x_train,y_train)
predictions = clfLog.predict(x_test)
print_stats_metrics(y_test, predictions)

#######################Decision Tree#######################
print("#######################Decision Tree#######################")
clfDT = DecisionTreeRegressor()
clfDT.fit(x_train,y_train)
predictions = clfDT.predict(x_test)
print_stats_metrics(y_test, predictions)

#######################Random Forest#######################
#print("#######################Random Forest#######################")
clfRF = RandomForestClassifier()
clfRF.fit(x_train,y_train)
predictions = clfSvm.predict(x_test)
print("#######################Random Forest#######################")
print_stats_metrics(y_test, predictions)